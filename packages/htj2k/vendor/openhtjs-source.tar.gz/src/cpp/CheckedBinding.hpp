#pragma once

#include <exception>
#include <functional>
#include <type_traits>
#include <emscripten/bind.h>
#include "HTDecoder.hpp"

// Return errors as values so C++ destroys the caught exception before JS throws.
template <auto Method, typename... Args>
auto checkedCall() {
  return emscripten::optional_override([](HTDecoder& decoder, Args... args) {
    using emscripten::val;
    try {
      if constexpr (std::is_void_v<std::invoke_result_t<decltype(Method), HTDecoder&, Args...>>) {
        std::invoke(Method, decoder, args...);
        return val::undefined();
      } else {
        return val(std::invoke(Method, decoder, args...));
      }
    } catch (const std::exception& error) {
      return val::global("Error").new_(val(error.what()));
    } catch (const char* message) {
      return val::global("Error").new_(val(message));
    }
  });
}

template <auto Method, typename Result, typename... Args>
auto checkedSignature(Result (HTDecoder::*)(Args...)) {
  return checkedCall<Method, Args...>();
}

template <auto Method, typename Result, typename... Args>
auto checkedSignature(Result (HTDecoder::*)(Args...) const) {
  return checkedCall<Method, Args...>();
}

template <auto Method>
auto checked() {
  return checkedSignature<Method>(Method);
}
