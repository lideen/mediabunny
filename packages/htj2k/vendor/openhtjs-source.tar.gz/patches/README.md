# Decoder-only OpenJPH build

`openjph-decoder-only.patch` applies to OpenJPH 0.32.0 in the Docker build copy.
The checked-out submodule remains unchanged, including its working native encoder.

OpenJPH initializes both encoder and decoder function pointers in
`codeblock_fun::init`, even for decoding. Those pointers retain two encoder kernels
and encoder table initialization that this wrapper cannot call. The patch sets the
encoder pointers to null and skips their table initialization. The linker then
discards the encoder code and tables. It does not change a decoder kernel.

This saves 24,784 raw bytes and about 4 KB Brotli in the measured `-Os`/LTO build.
The built library is intentionally decoder-only. Do not use the patched static
library for encoding or add an encoder export without removing this patch.

The build applies the patch with zero fuzz and fails if it no longer applies.
On an OpenJPH upgrade, review the initialization paths again, run the decode and
error tests, and compare full-precision pixels against an independent decoder.
Do not refresh patch offsets without checking the surrounding code.
