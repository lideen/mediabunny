#!/bin/sh
set -eu

cd "$(dirname "$0")/.."
if [ ! -f external/OpenJPH/src/core/openjph/ojph_codestream.h ]; then
  echo "Initialize the pinned dependency: git submodule update --init --recursive" >&2
  exit 1
fi

docker buildx build --output type=local,dest=dist "$@" .
